# Cache directory for transformer models
CACHE_DIR = "/n/holylabs/LABS/dwork_lab/Everyone/cache/transformers" 